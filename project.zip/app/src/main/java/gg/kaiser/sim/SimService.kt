package gg.kaiser.sim

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SimService : AccessibilityService() {

    companion object {
        @Volatile var instance: SimService? = null
        @Volatile var status: String = ""
        @Volatile var balance: Int = 57
    }

    // Запасные координаты (доли экрана), сняты со скриншотов 2340x1080
    private val F_PRICE = 0.616 to 0.659      // ценник «200» в магазине
    private val F_SVC_YES = 0.567 to 0.820    // жёлтая кнопка «200» в подтверждении услуги
    private val F_FIELD = 0.500 to 0.641      // поле ввода номера
    private val F_CHIP = 0.527 to 0.403       // подсказка клавиатуры с номером
    private val F_KB_DONE = 0.928 to 0.818    // «галочка» клавиатуры
    private val F_CONTINUE = 0.444 to 0.754   // «Продолжить»
    private val F_BUY = 0.444 to 0.613        // «Покупка»
    private val F_CANCEL = 0.558 to 0.615     // «Отмена» в подтверждении номера

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var worker: Thread? = null
    private var overlay: TextView? = null
    private val recent = ArrayList<Pair<Long, String>>()
    private var out: OutputStream? = null
    private var checked = 0
    private var found = 0

    // ---------- жизненный цикл ----------

    override fun onServiceConnected() {
        instance = this
        status = "Сервис включён. Открой игру кнопкой «2» в приложении."
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val sb = StringBuilder()
        e.text?.forEach { sb.append(it).append(' ') }
        e.contentDescription?.let { sb.append(it) }
        val s = sb.toString().trim()
        if (s.isNotEmpty()) synchronized(recent) {
            recent.add(System.currentTimeMillis() to s)
            while (recent.size > 60) recent.removeAt(0)
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        hideOverlay()
        instance = null
        status = ""
        return super.onUnbind(intent)
    }

    // ---------- плавающая кнопка ----------

    fun showOverlay() {
        main.post {
            if (overlay != null) return@post
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val tv = TextView(this)
            tv.text = if (running) "■ Стоп" else "▶ Старт"
            tv.textSize = 16f
            tv.setTextColor(0xFFFFFFFF.toInt())
            tv.setBackgroundColor(0xDD2A2A2D.toInt())
            tv.setPadding(36, 24, 36, 24)
            tv.setOnClickListener { toggle() }
            tv.setOnLongClickListener { hideOverlay(); true }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
            wm.addView(tv, lp)
            overlay = tv
        }
    }

    private fun hideOverlay() {
        main.post {
            val v = overlay ?: return@post
            try {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
            } catch (e: Exception) {
            }
            overlay = null
        }
    }

    private fun updateOverlay() {
        main.post { overlay?.text = if (running) "■ Стоп" else "▶ Старт" }
    }

    // ---------- запуск и остановка ----------

    private fun toggle() {
        if (running) stop() else start()
    }

    private fun start() {
        if (running) return
        running = true
        updateOverlay()
        worker = Thread {
            try {
                runLoop()
            } catch (e: Exception) {
                status = "Ошибка: " + e.message
            } finally {
                running = false
                updateOverlay()
                closeLog()
            }
        }.also { it.start() }
    }

    private fun stop() {
        running = false
        worker?.interrupt()
    }

    // ---------- основной цикл ----------

    private fun runLoop() {
        val nums = assets.open("numbers_6digit.txt").bufferedReader().readLines()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
        out = createOut("sim_found_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".txt")
        if (out == null) {
            status = "Не удалось создать файл в Download/GM_macro"
            return
        }
        checked = 0
        found = 0
        for (n in nums) {
            if (!running) break
            status = "Проверяю $n (${checked + 1}/${nums.size}), найдено: $found"
            if (!ensureInput()) {
                status = "Не вижу окно ввода номера. Открой «Покупка телефонного номера», нажми ▶. Если не помогает, сделай диагностику."
                return
            }
            typeNumber(n)
            clearRecent()
            if (!clickLabel("Продолжить")) tapFrac(F_CONTINUE)
            waitFor(3500) { isNumConfirm() || seen("занят") }
            if (isNumConfirm()) {
                val price = readPrice()
                if (price == null || price <= balance) {
                    status = "Остановился на $n: цена ${price ?: "не видна"}. Реши сам, покупать или нет."
                    log("# остановка на $n, цена $price")
                    return
                }
                clearRecent()
                if (!clickLabel("Покупка", true)) tapFrac(F_BUY)
                waitFor(3500) {
                    seen("Недостаточно") || recentHas("Недостаточно") || seen("занят") || recentHas("занят")
                }
                if (seen("Недостаточно") || recentHas("Недостаточно")) {
                    found++
                    log(n)
                    if (!clickLabel("ОК", true)) clickLabel("Закрыть", true)
                }
            }
            checked++
        }
        status = (if (running) "Готово. " else "Остановлено. ") + "Проверено $checked, найдено $found"
    }

    // ---------- состояния окон ----------

    private fun isInput() = seen("Введите номер телефона", "Покупка телефонного номера")
    private fun isNumConfirm() = seen("Вы желаете приобрести номер")
    private fun isSvcConfirm() = seen("Вы действительно хотите приобрести")

    private fun ensureInput(): Boolean {
        if (isInput()) return true
        if (isNumConfirm()) {
            if (!clickLabel("Отмена", true)) tapFrac(F_CANCEL)
            nap(200)
            if (isInput()) return true
        }
        if (!isSvcConfirm()) {
            tapFrac(F_PRICE)
            if (!waitFor(2500) { isSvcConfirm() || isInput() }) return false
        }
        if (isSvcConfirm()) {
            tapFrac(F_SVC_YES)
            if (!waitFor(2500) { isInput() }) return false
        }
        return isInput()
    }

    private fun typeNumber(n: String): Boolean {
        main.post {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("n", n))
        }
        nap(120)
        tapFrac(F_FIELD)
        // вариант 1: настоящее поле ввода, вписываем напрямую
        if (waitFor(700) { findEditable() != null }) {
            val edit = findEditable()
            if (edit != null) {
                val args = Bundle()
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, n)
                if (edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                    tapFrac(F_KB_DONE)
                    return true
                }
            }
        }
        // вариант 2: подсказка клавиатуры с номером из буфера обмена
        val chip = waitFor(1500) { exactNodes(n).isNotEmpty() }
        if (!chip || !clickLabel(n, true)) tapFrac(F_CHIP)
        nap(150)
        tapFrac(F_KB_DONE)
        return true
    }

    private fun readPrice(): Int? {
        val joined = screenTexts().joinToString(" ")
        val m = Regex("Цена\\D{0,3}(\\d+)").find(joined) ?: return null
        return m.groupValues[1].toIntOrNull()
    }

    // ---------- чтение экрана ----------

    private fun roots(): List<AccessibilityNodeInfo> {
        val list = try {
            windows.mapNotNull { it.root }
        } catch (e: Exception) {
            emptyList()
        }
        if (list.isNotEmpty()) return list
        return listOfNotNull(rootInActiveWindow)
    }

    private fun screenTexts(): List<String> {
        val res = ArrayList<String>()
        try {
            for (r in roots()) collect(r, res, 0)
        } catch (e: Exception) {
        }
        return res
    }

    private fun collect(n: AccessibilityNodeInfo?, res: MutableList<String>, d: Int) {
        if (n == null || d > 40) return
        n.text?.toString()?.takeIf { it.isNotBlank() }?.let { res.add(it) }
        n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { res.add(it) }
        n.hintText?.toString()?.takeIf { it.isNotBlank() }?.let { res.add(it) }
        for (i in 0 until n.childCount) collect(n.getChild(i), res, d + 1)
    }

    private fun seen(vararg labels: String): Boolean {
        val t = screenTexts()
        return labels.any { l -> t.any { it.contains(l, true) } }
    }

    private fun recentHas(vararg labels: String): Boolean = synchronized(recent) {
        recent.any { e -> labels.any { e.second.contains(it, true) } }
    }

    private fun clearRecent() = synchronized(recent) { recent.clear() }

    private fun findNodes(label: String): List<AccessibilityNodeInfo> {
        val res = ArrayList<AccessibilityNodeInfo>()
        for (r in roots()) res.addAll(r.findAccessibilityNodeInfosByText(label))
        return res
    }

    private fun exactNodes(label: String): List<AccessibilityNodeInfo> =
        findNodes(label).filter {
            (it.text ?: it.contentDescription)?.toString()?.trim().equals(label, true)
        }

    private fun findEditable(): AccessibilityNodeInfo? {
        for (r in roots()) {
            val f = firstMatch(r, 0) { it.isEditable }
            if (f != null) return f
        }
        return null
    }

    private fun firstMatch(n: AccessibilityNodeInfo?, d: Int, p: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null || d > 40) return null
        if (p(n)) return n
        for (i in 0 until n.childCount) {
            val f = firstMatch(n.getChild(i), d + 1, p)
            if (f != null) return f
        }
        return null
    }

    // ---------- нажатия ----------

    private fun clickLabel(label: String, exactOnly: Boolean = false): Boolean {
        val exact = exactNodes(label).firstOrNull()
        val node = exact ?: (if (exactOnly) null else findNodes(label).firstOrNull()) ?: return false
        return clickNode(node)
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var hops = 0
        while (c != null && hops < 6) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            hops++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        val ok = dispatchGesture(g, null, null)
        nap(90)
        return ok
    }

    private fun tapFrac(p: Pair<Double, Double>): Boolean {
        val (w, h) = screenSize()
        return tap((w * p.first).toFloat(), (h * p.second).toFloat())
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun nap(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            running = false
        }
    }

    private fun waitFor(timeout: Long, cond: () -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeout
        while (running && System.currentTimeMillis() < end) {
            if (cond()) return true
            nap(70)
        }
        return false
    }

    // ---------- файлы и диагностика ----------

    private fun createOut(name: String): OutputStream? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/GM_macro")
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                if (uri == null) null else contentResolver.openOutputStream(uri, "wa")
            } else {
                java.io.File(getExternalFilesDir(null), name).outputStream()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun log(s: String) {
        try {
            out?.write((s + "\n").toByteArray())
            out?.flush()
        } catch (e: Exception) {
        }
    }

    private fun closeLog() {
        try {
            out?.close()
        } catch (e: Exception) {
        }
        out = null
    }

    fun dumpScreenDelayed() {
        status = "Дамп через 8 секунд: открой окно в игре"
        Thread {
            try {
                Thread.sleep(8000)
            } catch (e: InterruptedException) {
            }
            dump()
        }.start()
    }

    private fun dump() {
        val sb = StringBuilder()
        val ws = try { windows } catch (e: Exception) { emptyList() }
        for (w in ws) {
            sb.append("== окно type=").append(w.type).append(" layer=").append(w.layer)
                .append(" title=").append(w.title).append('\n')
            dumpNode(w.root, 0, sb)
        }
        if (ws.isEmpty()) dumpNode(rootInActiveWindow, 0, sb)
        sb.append("\n== события (последние)\n")
        synchronized(recent) { recent.forEach { sb.append(it.second).append('\n') } }
        val name = "gm_dump_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        val o = createOut(name)
        if (o == null) {
            status = "Не удалось записать дамп"
            return
        }
        try {
            o.write(sb.toString().toByteArray())
            o.close()
            status = "Дамп записан: Download/GM_macro/$name"
        } catch (e: Exception) {
            status = "Ошибка дампа: " + e.message
        }
    }

    private fun dumpNode(n: AccessibilityNodeInfo?, d: Int, sb: StringBuilder) {
        if (n == null || d > 40) return
        val r = Rect()
        n.getBoundsInScreen(r)
        sb.append("  ".repeat(d)).append(n.className)
            .append(" text=").append(n.text)
            .append(" desc=").append(n.contentDescription)
            .append(" id=").append(n.viewIdResourceName)
            .append(" click=").append(n.isClickable)
            .append(" edit=").append(n.isEditable)
            .append(' ').append(r.toShortString()).append('\n')
        for (i in 0 until n.childCount) dumpNode(n.getChild(i), d + 1, sb)
    }
}
