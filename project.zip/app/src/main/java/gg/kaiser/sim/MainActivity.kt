package gg.kaiser.sim

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val keyOk = "kaiserpm"
    private val gamePackage = "com.grand.launcher"
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var keyInput: EditText
    private lateinit var panel: LinearLayout
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun params(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.parseColor("#111111"))
        background = box(Color.parseColor("#F2F2F2"), 12)
        setOnClickListener { action() }
    }

    private fun watcher(onChange: (String) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { onChange(s?.toString() ?: "") }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.parseColor("#C8C8CC"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.parseColor("#2A2A2D"), 20)
            setPadding(dp(22), dp(28), dp(22), dp(24))
        }

        card.addView(TextView(this).apply {
            text = "Telegram kaiserpm"
            textSize = 24f
            setTextColor(Color.parseColor("#F2F2F2"))
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }, params(bottom = 22))

        keyInput = EditText(this).apply {
            hint = "Введите ключ"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#F2F2F2"))
            setHintTextColor(Color.parseColor("#9A9A9F"))
            background = box(Color.parseColor("#1C1C1E"), 12)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            addTextChangedListener(watcher { if (it.trim() == keyOk) unlock() })
        }
        card.addView(keyInput, params())

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        panel.addView(makeButton("1. Включить сервис") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, params(bottom = 10))
        panel.addView(makeButton("2. Открыть Grand Mobile") { openGame() }, params(bottom = 14))

        panel.addView(label("Ваш баланс GC (если цена не выше, остановлюсь и ничего не куплю)"), params(bottom = 6))
        val balance = EditText(this).apply {
            setText("57")
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#F2F2F2"))
            background = box(Color.parseColor("#1C1C1E"), 12)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            inputType = InputType.TYPE_CLASS_NUMBER
            addTextChangedListener(watcher { SimService.balance = it.toIntOrNull() ?: 0 })
        }
        panel.addView(balance, params(bottom = 14))

        panel.addView(makeButton("Диагностика: записать тексты экрана") {
            val svc = SimService.instance
            if (svc == null) {
                toast("Сначала включи сервис")
            } else {
                toast("Через 8 секунд запишу. Открой окно в игре")
                svc.dumpScreenDelayed()
            }
        }, params(bottom = 14))

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#C8C8CC"))
            gravity = Gravity.CENTER
        }
        panel.addView(status, params())
        card.addView(panel, params(top = 6))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        col.addView(card, params())

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            addView(col, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }
        setContentView(scroll)
        ui.post(refresh)
    }

    private val refresh = object : Runnable {
        override fun run() {
            status.text = if (SimService.instance == null)
                "Сервис выключен. Включи «kaiserpm» в Специальных возможностях."
            else SimService.status
            ui.postDelayed(this, 500)
        }
    }

    private fun unlock() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(keyInput.windowToken, 0)
        keyInput.visibility = View.GONE
        panel.visibility = View.VISIBLE
    }

    private fun openGame() {
        val svc = SimService.instance
        if (svc == null) {
            toast("Сначала включи сервис")
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(gamePackage)
        if (intent == null) {
            toast("Игра не найдена на телефоне")
            return
        }
        svc.showOverlay()
        startActivity(intent)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        ui.removeCallbacks(refresh)
        super.onDestroy()
    }
}
